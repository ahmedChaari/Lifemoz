<?php

namespace ContactManager\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{

}
