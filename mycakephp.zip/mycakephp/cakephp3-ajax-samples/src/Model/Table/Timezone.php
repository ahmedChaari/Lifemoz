namespace App\Model\Table;

use Cake\ORM\Table;

class TimezoneTable extends Table
{

}
